<style>
    font-family:sans-serif;
</style>
<h1>Lista de filmes</h1>

<?php


use App\Models\Film;

// Recupera todos os filmes
$films = Film::all();

foreach ($films as $film) {
    echo $film->first_name . "<br>";
}
?>